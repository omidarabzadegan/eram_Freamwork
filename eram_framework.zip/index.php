<?php
include "bootstrap/init.php";
echo assets_url('');
?>

<link rel="stylesheet" href="<?= assets_url('css/style.css') ?>">
